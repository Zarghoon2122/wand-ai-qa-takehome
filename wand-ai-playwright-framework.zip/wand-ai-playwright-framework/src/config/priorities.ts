export const PRIORITY = {
  P1: 'Critical / Blocker',
  P2: 'Major',
  P3: 'Minor'
};