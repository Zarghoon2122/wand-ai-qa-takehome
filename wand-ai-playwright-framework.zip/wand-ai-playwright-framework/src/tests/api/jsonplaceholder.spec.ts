import { test, expect } from '@playwright/test';
import fetch from 'node-fetch';

test('GET /posts returns array', async () => {
  const res = await fetch('https://jsonplaceholder.typicode.com/posts');
  expect(res.status).toBe(200);
  const data = await res.json();
  expect(Array.isArray(data)).toBeTruthy();
});