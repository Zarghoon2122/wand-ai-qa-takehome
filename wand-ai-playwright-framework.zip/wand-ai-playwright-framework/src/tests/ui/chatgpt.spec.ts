import { test, expect } from '@playwright/test';

test('ChatGPT page load and basic prompt', async ({ page }) => {
  await page.goto('https://chat.openai.com/');
  await expect(page).toHaveTitle(/ChatGPT/i);
  const input = page.locator('textarea');
  await expect(input).toBeVisible();
  await input.fill('Hello, test');
  await page.keyboard.press('Enter');
  const response = page.locator('.result-streaming'); // example selector
  await expect(response.first()).toBeVisible();
});