import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/saucedemo/LoginPage';
import { ProductsPage } from '../../pages/saucedemo/ProductsPage';

test('SauceDemo login and add product to cart', async ({ page }) => {
  const login = new LoginPage(page);
  await login.goto();
  await login.login('standard_user', 'secret_sauce');
  const products = new ProductsPage(page);
  await products.addFirstProductToCart();
  const count = await products.getCartCount();
  expect(count).toBe(1);
});