import { Page } from '@playwright/test';
export class ProductsPage {
  constructor(public page: Page) {}
  async addFirstProductToCart() {
    await this.page.click('button[id^=add-to-cart]');
  }
  async getCartCount() {
    return parseInt(await this.page.textContent('.shopping_cart_badge') || '0');
  }
}